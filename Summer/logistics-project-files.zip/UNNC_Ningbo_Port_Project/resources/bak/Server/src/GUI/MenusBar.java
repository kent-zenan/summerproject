package GUI;

import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

public class MenusBar extends JMenuBar{
	JMenuItem jmiLanguage = new JMenuItem("Langauge", 'L');
	
	public MenusBar() {
		super();
		JMenu jmPreference = new JMenu("Preference");
		jmPreference.setMnemonic('P');
		add(jmPreference);
		
		jmPreference.add(jmiLanguage);
		
	}
}
