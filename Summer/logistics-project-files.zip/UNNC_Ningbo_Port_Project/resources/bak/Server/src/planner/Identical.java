package planner;

public abstract interface Identical<T> {
	public abstract boolean geographicallyIdenticalTo(T t);
}
