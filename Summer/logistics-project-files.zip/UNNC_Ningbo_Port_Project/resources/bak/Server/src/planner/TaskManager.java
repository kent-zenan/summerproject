package planner;

/*
 * This class manages the status of tasks
 * If a small task turns out to be heavy, then it will split it and mark that
 * heave one as "heavy"
 */
public class TaskManager {

}
