package planner;

/*
 * This class monitors the vehicle state
 */
public class VehicleManager {

}
