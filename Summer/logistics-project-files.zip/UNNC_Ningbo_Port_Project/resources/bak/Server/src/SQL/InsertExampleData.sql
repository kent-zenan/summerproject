INSERT INTO driver VALUES("Alex", "politics");
INSERT INTO driver VALUES("Turing", "computers");
INSERT INTO driver VALUES("Jane", "smartypants");

INSERT INTO vehicle VALUES ("9A773");
INSERT INTO vehicle VALUES ("8S583");
INSERT INTO vehicle VALUES ("11223");