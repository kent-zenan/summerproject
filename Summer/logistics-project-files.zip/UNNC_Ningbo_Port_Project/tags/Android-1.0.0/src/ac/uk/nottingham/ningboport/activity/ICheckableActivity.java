package ac.uk.nottingham.ningboport.activity;

public interface ICheckableActivity {
	
	public boolean isRunning();
}
