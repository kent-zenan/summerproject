package uk.ac.nottingham.ningboport.planner;

/*
 * This class monitors the vehicle state
 */
public class VehicleManager {

}
