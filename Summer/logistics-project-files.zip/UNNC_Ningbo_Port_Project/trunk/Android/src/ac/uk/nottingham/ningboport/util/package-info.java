/**
 * Build XML string from an data object and interpreter XML string to form a data object
 * 
 * @author Jiaqi LI
 */
package ac.uk.nottingham.ningboport.util;
