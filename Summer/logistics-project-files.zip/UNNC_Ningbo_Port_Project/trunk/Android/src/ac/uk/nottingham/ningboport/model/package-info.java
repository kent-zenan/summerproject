/**
 * Data model used by the application.
 */
package ac.uk.nottingham.ningboport.model;