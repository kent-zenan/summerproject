	$(function() {

	//Speed
	var slide_int_speed = null;
	var slide_int_taxicabs = null;
	var slide_int_passengers = null;
	
	function update_slider_speed(){
		var value = $('#slider-speed').slider('option', 'value');
			$('#speed-value').text('Simulation Speed: '+value);
			$('#speed-value').fadeIn();
	}
	
	function update_slider_taxicabs(){
		var valuet = $('#slider-taxicabs').slider('option', 'value');
			$('#taxicabs-value').text('No. of Taxicabs: '+valuet);
			$('#taxicabs-value').fadeIn();
	}
	
	function update_slider_passengers(){
		var valuep = $('#slider-passengers').slider('option', 'value');
			$('#passengers-value').text('No. of Passengers: '+valuep);
			$('#passengers-value').fadeIn();
	}
		
	$( "#slider-speed" ).slider({
		start: function(event, ui){
		$('#speed-value').empty();
			slide_int_speed = setInterval(update_slider_speed, 10);	
		},
		slide: function(event, ui) 
		{ 
			setTimeout(update_slider_speed, 10); 
		},
		stop: function(event, ui){
			clearInterval(slide_int_speed);
			slide_int_speed = null;
		}
	});
	
	$( "#slider-taxicabs" ).slider({
		start: function(event, ui){
			$('#taxicabs-value').empty();
				slide_int_taxicabs = setInterval(update_slider_taxicabs, 10);
			},
		slide: function(event, ui) 
			{ 
				setTimeout(update_slider_taxicabs, 10); 
			},
		stop: function(event, ui){
			clearInterval(slide_int_taxicabs);
			slide_int_taxicabs = null;
		}
	});
	
	$( "#slider-passengers" ).slider({
		start: function(event, ui){
			$('#passengers-value').empty();
				slide_int_passengers = setInterval(update_slider_passengers, 10);
			},
		slide: function(event, ui) 
			{ 
				setTimeout(update_slider_passengers, 10); 
			},
		stop: function(event, ui){
			clearInterval(slide_int_passengers);
			slide_int_passengers = null;
		}
	});
	
	
	var rollout_visible = false;
		// run the currently selected effect
		function runEffect() {
			// get effect type from 
			var selectedEffect = 'drop';
			var options = { direction: "down" };

			// most effect types need no options passed by default
			var options = {};
			// some effects have required parameters
			if ( rollout_visible === false ) {
				$( "#effect" ).show( selectedEffect, { direction: "up" }, 500, callback );
				rollout_visible = true;
				//options = { percent: 100 };
			} else {
				$( "#effect:visible" ).removeAttr( "style" ).fadeOut();
				rollout_visible = false;
				//options = { to: { width: 280, height: 185 } };
			}

			// run the effect
			
		};

		//callback function to bring a hidden box back
		function callback() {
//			setTimeout(function() {
//				$( "#effect:visible" ).removeAttr( "style" ).fadeOut();
//			}, 1000 );
		};
		

		// set effect when simulation
		$( "#button-simulate" ).click(function() {
			runEffect();
			$( "#dialog" ).dialog('open');
			//$('#button-simulate').hide();
			//$( "#button-simulate" ).disable();
			return false;
		});
	
		

		// set effect from select menu value
		$( "#button" ).click(function() {
			runEffect();
			return false;
		});
		
		// set effect from select menu value
		$( "#button-demo" ).click(function() {
			return true;
		});
		
		//hide window initially
		$( "#effect" ).hide();
		
	});
	
	
	