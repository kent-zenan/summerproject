package com.unnc.smartcab.cab;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.OverlayItem;

/**
 * This class represents taxicabs
 * 
 * @author The University of Nottingham Ningbo China, Division of Computer
 *         Science
 * @version 1.0, Mar 2011 Contains taxicab attributes
 */
public class Cab extends OverlayItem {

	double speed = 0.0;
	CabStatus status = CabStatus.VEHICLE_VACANT;
	static String preTitle = "Taxicab ";

	/**
	 * Constructor for Cab class
	 * 
	 * @param gp
	 * @param id
	 * @param snippet
	 */
	public Cab(GeoPoint gp, String id, String snippet) {
		super(gp, id, snippet);
	}

	/**
	 * Gets the title for the element
	 */
	@Override
	public String getTitle() {
		return preTitle + this.mTitle;
	}

	/**
	 * Gets ID for this Cab
	 * 
	 * @return
	 */
	public String getID() {
		return this.mTitle;
	}

	/**
	 * Gets the point (position) associated with this cab.
	 */
	@Override
	public GeoPoint getPoint() {
		return this.mPoint;
	}

	/**
	 * Gets the speed associated with this cab
	 * 
	 * @return
	 */
	public double getSpeed() {
		return speed;
	}

	/**
	 * Sets the speed associated with this vehicle
	 * 
	 * @param speed
	 */
	public void setSpeed(double speed) {
		this.speed = speed;
	}

	/**
	 * Gets the status of this cab
	 * 
	 * @return
	 */
	public CabStatus getStatus() {
		return status;
	}

	/**
	 * Sets the status for this cab
	 * 
	 * @param status
	 */
	public void setStatus(CabStatus status) {
		this.status = status;
	}

}
