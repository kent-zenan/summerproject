package com.unnc.smartcab;

/**
 * This is an enumeration for the mode of the application
 * 
 * @author The University of Nottingham Ningbo China, Division of Computer
 *         Science
 * @version 1.0, Mar 2011 Modes are passenger, driver and developer
 */

public enum AppMode {

	MODE_PASSENGER, MODE_DRIVER, MODE_DEVELOPER;
}
