SmartCab for Android v1.0
December 2011

Developed in eclipse for Android version 2.2

1. Configure your Android development environment
2. Copy this folder in your workspace
3. Deploy in device or emulator


